var express    = require("express"),
    router     = express.Router();
// SHOW ALL LISTINGS
router.get("/", function(req, res){
	var context = {};
	var mysql = req.app.get('mysql');
	getListings(res, mysql, context, complete);
	function complete(){
		res.render('listings/index', context);
	}
});
// CREATE - add new listing to database
router.post("/", function(req, res){
    var mysql = req.app.get('mysql');
    var sql = "INSERT INTO Listings(listing_picture, listing_address, listing_state, listing_city, listing_zipcode, listing_price, accepted_pets, accomodations) VALUES (?,?,?,?,?,?,?,?)";
    console.log(req.body);
    var inserts = [req.body.listing_picture, req.body.listing_address, req.body.listing_city, req.body.listing_state, req.body.listing_zipcode, req.body.listing_price, req.body.accepted_pets, req.body.accomodations, req.body.begin_date, req.body.end_date, req.body.begin_at, req.body.end_at];
    console.log("inserts", inserts);
    sql = mysql.pool.query(sql, inserts,function(error, results, fields){
        if(error){
            req.flash("error", JSON.stringify(error));
            res.redirect("/listings");
        }else if(results.affectedRows == 0){
            req.flash("error", "Listing not added!");
            res.redirect("/listings");
        }else{
            req.flash("success", "Listing successfully added!");
            res.redirect('/listings');
        }
    });
});
// NEW - Show form to create new listing
router.get("/new", function(req, res){
    res.render('listings/new');
});
// SHOW - Show more info about one listing
router.get("/:id", function(req, res){
    console.log("In show route");
    var context = {};
    var mysql = req.app.get('mysql');
    var count = 0;
    getListing(res, mysql, context, req.params.id, complete);
    getBookings(res, mysql, context, req.params.id, complete);
    function complete(){
        if(++count === 2){
            if(context.listing == undefined){
                req.flash("error", "Listing not found!");
                res.redirect('/listings');
            }else{
                res.render('listings/show', context);
            }
        }
    }
});
// EDIT listing
router.get("/:id/edit", function(req, res){
    var context = {};
    var mysql = req.app.get('mysql');
    getListing(res, mysql, context, req.params.id, complete);
    function complete(){
        if(context.listing == undefined){
            req.flash("error", "Listing not found!");
            res.redirect('/listings');
        }else
            res.render('listings/edit', context);
    }
});
// UPDATE listing
router.put("/:id", function(req, res){
    var mysql = req.app.get('mysql');
    var sql = "UPDATE Listings SET listing_picture=?, listing_address=?, listing_city=?, listing_state=?, listing_zipcode=?, listing_price=?, accepted_pets=?, accomodations=? WHERE listing_id=?"; 
 	var inserts = [req.body.listing_picture, req.body.listing_address, req.body.listing_city, req.body.listing_state, req.body.listing_zipcode, req.body.listing_price, req.body.accepted_pets, req.body.accomodations, req.params.id];
    sql = mysql.pool.query(sql,inserts,function(error, results, fields){
        if(error){
            req.flash("error", JSON.stringify(error));
            res.redirect("/listings");
        }else if(results.affectedRows == 0){
            req.flash("error", "Listing not found!");
            res.redirect("/listings");
        }else{
            req.flash("success", "Listing successfully updated!");
            res.redirect('/listings');
        }
    });
});
// DELETE listing
router.delete("/:id", function(req, res){
    var mysql = req.app.get('mysql');
    var sql = "DELETE FROM Listings WHERE listing_id = ?";
        // remember that these inserts are URL encoded
    var inserts = [req.params.id];
    sql = mysql.pool.query(sql,inserts,function(error, results, fields){
        console.log(results);
        if(error){
            req.flash("error", JSON.stringify(error));
            res.redirect("/listings");
        }else if(results.affectedRows == 0){
            req.flash("error", "Listing not found!");
            res.redirect("/listings");
        }
        else{
            res.status(200);
            req.flash("success", "Listing successfully deleted!");
            res.redirect('/listings');
        }
    });
});
module.exports = router;
function getListings(res, mysql, context, complete){
    var sql = "SELECT * FROM Listings";
    mysql.pool.query(sql, function(error, results, fields){
        if(error){
            res.write(JSON.stringify(error));
            res.end();
        }
        console.log(results);
        context.listings = results;
        complete();
    });
}
function getListing(res, mysql, context, id, complete){
    var sql = "SELECT * FROM Listings WHERE listing_id = ?";
    var inserts = [id];
    mysql.pool.query(sql, inserts, function(error, results, fields){
        if(error){
            res.write(JSON.stringify(error));
            res.end();
        }
        context.listing = results[0];
        // var beginYearDate = results[0].begin_date.getFullYear();
        // var beginMonthDate = ('0' + (results[0].begin_date.getMonth()+1)).slice(-2)
        // var beginDayDate = results[0].begin_date.getDate();
        // var endYearDate = results[0].end_date.getFullYear();
        // var endMonthDate = ('0' + (results[0].end_date.getMonth()+1)).slice(-2)
        // var endDayDate = results[0].end_date.getDate();

        // context.listing = results[0];
        // context.listing.begin_date = beginYearDate + '-' + beginMonthDate + '-' + beginDayDate;
        // context.listing.end_date =  endYearDate + '-' + endMonthDate + '-' + endDayDate;
        // console.log(context.listing);
        // context.listing.RowDataPacket.begin_date = context.pet.begin_date.toDate();
        // context.listing.RowDataPacket.end_date = context.pet.end_date.toDate();
        complete();
    });
}

function getBookings(res, mysql, context, id, complete){
    var sql = "SELECT DATE_FORMAT(begin_date, '%m/%d/%Y') AS begin_date, DATE_FORMAT(end_date, '%m/%d/%Y') AS end_date FROM Bookings WHERE lid = ? ";
    var inserts = [id];
    mysql.pool.query(sql, inserts, function(error, results, fields){
        if(error){
            res.write(JSON.stringify(error));
            res.end();
        }



        context.listings = results;
        console.log(context);
        complete();
    });
}