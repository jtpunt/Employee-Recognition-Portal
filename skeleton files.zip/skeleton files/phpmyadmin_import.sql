DROP TABLE IF EXISTS `Accounts`;

-- create accounts database
CREATE TABLE Accounts(
  user_id       int           NOT NULL AUTO_INCREMENT,
  user_name     varchar(30)   NOT NULL,
  user_address  varchar(25)   NOT NULL,
  phone_number  varchar(50)   NOT NULL,
  user_email    varchar(50) 	NOT NULL,
  user_pw   		varchar(50)   NOT NULL,
  acc_type			varchar(20)		NOT NULL,
  PRIMARY KEY (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- adding new user
INSERT INTO Accounts(user_name, user_address, phone_number, user_email, user_pw, acc_type)
	VALUES ("TestUserName", "TestUserAddress", "TestUserPhone", "TestUserEmail", "TestUserPW", "Pet Owner");

DROP TABLE IF EXISTS `Pets`;

CREATE TABLE Pets(
  pet_id        int           NOT NULL AUTO_INCREMENT,
  pet_name      varchar(30)   NOT NULL,
  pet_type      varchar(25)   NOT NULL,
  pet_breed     varchar(50)   NOT NULL,
  pet_weight    decimal(3, 2) NOT NULL,
  pet_picture   text          NOT NULL,
  pet_diet      text          NOT NULL,
  medications   text          NOT NULL,
  special_needs text          NOT NULL,
  PRIMARY KEY (pet_id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



INSERT INTO Pets(pet_type, pet_name, pet_breed, pet_weight, pet_picture, pet_diet, medications, special_needs) VALUES ("cat", "Flavortown", "abyssinian", 15.56,
 "https://www.tica.org/images/breeds/2017/ab_a.jpg", "Hills Prescription Diet - Kidney Care", "Enalapril - 2.5mg, Tramadol - 50mg, Cerenia-16mg",
 "Cerenia must be given 2x a day, 0.25ml each. Enalapril must be given once a day, at a half a pill. Tramadol may be given once a day - as needed, at a quarter of a pill");

 INSERT INTO Pets(pet_type, pet_name, pet_breed, pet_weight, pet_picture, pet_diet, medications, special_needs) VALUES ("cat", "Smaug", "Maine Coon", 20.56,
 "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRo8HV9U9HC0A0BkbbuUBWZVa0t45meGzW3aP4SXk0NLAK1mNgg", "Hills Science Diet - Perfect Weight", "None", "None");

  INSERT INTO Pets(pet_type, pet_name, pet_breed, pet_weight, pet_picture, pet_diet, medications, special_needs) VALUES ("dog", "Bella", "Maine Coon", 40.56,
 "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRo8HV9U9HC0A0BkbbuUBWZVa0t45meGzW3aP4SXk0NLAK1mNgg", "Hills Science Diet - Perfect Weight", "None", "None");

  INSERT INTO Pets(pet_type, pet_name, pet_breed, pet_weight, pet_picture, pet_diet, medications, special_needs) VALUES ("dog", "Penny",  "Maine Coon", 50.56,
 "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRo8HV9U9HC0A0BkbbuUBWZVa0t45meGzW3aP4SXk0NLAK1mNgg", "Hills Science Diet - Perfect Weight", "None", "None");
  
  DROP TABLE IF EXISTS `Bookings`;
  DROP TABLE IF EXISTS `Listings`;

  CREATE TABLE Listings(
    listing_id      int            NOT NULL AUTO_INCREMENT,
    listing_picture text           NOT NULL,
    listing_address text           NOT NULL,
    listing_state   varchar(50)    NOT NULL,
    listing_city    varchar(100)   NOT NULL,
    listing_zipcode varchar(5)     NOT NULL,
    listing_price   decimal(4, 2)  NOT NULL,
    accepted_pets   text           NOT NULL,
    accomodations   text           NOT NULL,
    PRIMARY KEY(listing_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=latin1;


  CREATE TABLE Bookings(
    booking_id      int            NOT NULL AUTO_INCREMENT,
    lid      int            NOT NULL,
    begin_date      date           NOT NULL,
    end_date        date           NOT NULL,
    begin_at        time           NOT NULL,
    end_at          time           NOT NULL,
    FOREIGN KEY(lid) REFERENCES Listings (listing_id) ON DELETE CASCADE ON UPDATE CASCADE,
    PRIMARY KEY(booking_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=latin1;


  INSERT INTO Listings(listing_picture, listing_address, listing_state, listing_city, listing_zipcode, listing_price, accepted_pets, accomodations) VALUES
  ("https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260",
    "170 Woodland Drive", "Chicago", "Illinois", "60606", 50.99,
    "cats, dogs, birds", "Can take animals into the backyard and watch them.");

  INSERT INTO Listings(listing_picture, listing_address, listing_state, listing_city, listing_zipcode, listing_price, accepted_pets, accomodations) VALUES
  ("https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260",
    "3723 Marion Drive", "Tampa", "Florida", "33619", 60.99,
    "cats, dogs, birds", "Can take animals into the backyard and watch them.");

  INSERT INTO Listings(listing_picture, listing_address, listing_state, listing_city, listing_zipcode, listing_price, accepted_pets, accomodations) VALUES
  ("https://images.pexels.com/photos/259600/pexels-photo-259600.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260",
    "1571 Shearwood Forest Drive", "West Stewartstown", "NH", "03597", 99.99,
    "cats, dogs, birds", "Can take animals into the backyard and watch them.");

  INSERT INTO Listings(listing_picture, listing_address, listing_state, listing_city, listing_zipcode, listing_price, accepted_pets, accomodations) VALUES
  ("https://images.pexels.com/photos/462358/pexels-photo-462358.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260",
    "2028 Pinewood Avenue", "Marquette", "Michigan", "49855", 150.99,
    "cats, dogs, birds", "Can take animals into the backyard and watch them.");

  INSERT INTO Listings(listing_picture, listing_address, listing_state, listing_city, listing_zipcode, listing_price, accepted_pets, accomodations) VALUES
  ("https://images.pexels.com/photos/534182/pexels-photo-534182.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260",
    "979 Ferrell Street", "Cass Lake", "Minnesota", "56633", 79.99,
    "cats, dogs, birds", "Can take animals into the backyard and watch them.");

  INSERT INTO Listings(listing_picture, listing_address, listing_state, listing_city, listing_zipcode, listing_price, accepted_pets, accomodations) VALUES
  ("https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260",
    "592 Deercove Drive", "Dallas", "Texas", "75247", 49.99,
    "cats, dogs, birds", "Can take animals into the backyard and watch them.");

INSERT INTO Bookings (lid, begin_date, end_date, begin_at, end_at) Values
(1,'2018-01-25', '2018-02-24', '080000', '173000'),
(1,'2018-03-24', '2018-04-20', '080000', '173000'),
(1,'2018-06-24', '2018-07-15', '080000', '173000'),
(1,'2018-08-03', '2018-08-14', '080000', '173000'),
(1,'2018-10-24', '2018-11-25', '080000', '173000'),
(1,'2018-12-24', '2019-01-05', '080000', '173000'),
(2,'2018-01-25', '2018-02-24', '080000', '173000'),
(2, '2018-03-24', '2018-04-20', '080000', '173000'),
(2,'2018-06-24', '2018-07-15', '080000', '173000'),
(2,'2018-08-03', '2018-08-14', '080000', '173000'),
(2,'2018-10-24', '2018-11-25', '080000', '173000'),
(2,'2018-12-24', '2019-01-05', '080000', '173000'),
(3,'2018-01-25', '2018-02-24', '080000', '173000'),
(3,'2018-03-24', '2018-04-20', '080000', '173000'),
(3,'2018-06-24', '2018-07-15', '080000', '173000'),
(3,'2018-08-03', '2018-08-14', '080000', '173000'),
(3,'2018-10-24', '2018-11-25', '080000', '173000'),
(3,'2018-12-24', '2019-01-05', '080000', '173000'),
(4,'2018-01-25', '2018-02-24', '080000', '173000'),
(4,'2018-10-24', '2018-11-25', '080000', '173000'),
(4,'2018-12-24', '2019-01-05', '080000', '173000'),
(5,'2018-01-25', '2018-02-24', '080000', '173000'),
(5,'2018-09-24', '2018-08-24', '080000', '173000'),
(5,'2018-11-25', '2018-12-24', '080000', '173000'),
(6,'2018-01-25', '2018-03-24', '080000', '173000'),
(6,'2018-07-25', '2018-09-24', '080000', '173000'),
(6,'2018-11-25', '2018-12-24', '080000', '173000');
